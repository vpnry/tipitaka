#!/usr/bin/bash

# Download and convert https://tipitaka.org/romn/
# XML to HTML Website

# Roman digitalised pali text are copyright
# by VRI, one may need to obtain their permission first
# Created for a personal project
# The code is messy and may have bugs,
# Use at oneself risks, no warranty!

# Use aria2 for parallel downloads. wget will take longer time

# Install aria2 on Termux (Android): 
    # pkg install aria2 zip unzip

# On Ubuntu
# sudo apt update
# sudo apt install zip unzip aria2

# # vrixml2web.zip is about 66KB

# wget -c https://vpnry.github.io/tipitaka/dev/vrixml2web.zip

# unzip vrixml2web.zip -d VRI
# cd VRI
# bash vrixml2web.sh


mkdir -p vri-toc-xml
mkdir -p vri-cscd-xml

echo 'Downloading VRI XML... it may take a while, please wait...'
    aria2c --dir=vri-toc-xml --input-file=dev/vri-toc-xml.txt --log=delete_this_download_log_vri-toc-xml.txt --continue=true --max-concurrent-downloads=10 --max-overall-download-limit=0 --check-certificate=false
    aria2c --dir=vri-cscd-xml --input-file=dev/vri-cscd-xml.txt --log=delete_this_download_log_vri_cscd-xml.txt --continue=true --max-concurrent-downloads=10 --max-overall-download-limit=0 --check-certificate=false

echo 'Done, re-check (only download again if needed) to make sure all files are completed'
    aria2c --dir=vri-toc-xml --input-file=dev/vri-toc-xml.txt --log=delete_this_download_log_vri-toc-xml.txt --continue=true --max-concurrent-downloads=10 --max-overall-download-limit=0 --check-certificate=false
    aria2c --dir=vri-cscd-xml --input-file=dev/vri-cscd-xml.txt --log=delete_this_download_log_vri_cscd-xml.txt --continue=true --max-concurrent-downloads=10 --max-overall-download-limit=0 --check-certificate=false

echo 'Downloading task is done'

echo 'Generating web from XML!'
    cp ./dev/vrixml2web.js ./
    node vrixml2web.js
    
echo 'Cleaning up'
    rm -f vrixml2web.js
    zip -m -j -r vri-toc-xml.zip vri-toc-xml
    zip -m -j -r vri-cscd-xml.zip vri-cscd-xml
    rm -rf vri-toc-xml
    rm -rf vri-cscd-xml

echo 'All done. Web generated!'
