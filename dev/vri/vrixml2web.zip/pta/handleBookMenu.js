/* uPnry - last modified 01-04-2021*/

var nowToc = false;
let buttonGoHome = "";
var PTT_CURRENT_BOOK = localStorage.getItem("PTT_CURRENT_BOOK");

if (PTT_CURRENT_BOOK) {
    buttonGoHome = `<button><a style="text-decoration: none;" href="../${PTT_CURRENT_BOOK}"> 📚 Home</a></button><span>  </span><button> Hide TOC</button>`;
} else {
    buttonGoHome = `<button><a style="text-decoration: none;" href="../index.html"> 📚 Home</a></button><span>  </span><button> Hide TOC</button>`;
}

function showHideToc() {
    var button = document.getElementById("floatingTocButton");
    var tocbox = document.getElementById("tocDivBox");
    if (nowToc) {
        nowToc = false;
        tocbox.style.display = "none";

        // button.textContent = " = "; does not work inside VRI (old ES?)
        button.innerText = " 📜 ";
        button.style.background = "";
        button.style.color = "red";
    } else {
        nowToc = true;
        tocbox.style.display = "";

        button.innerHTML = buttonGoHome;

        button.style.background = "#ccc";
        button.style.color = "brown";
    }
}

function onlyHideToc() {
    var button = document.getElementById("floatingTocButton");
    var tocbox = document.getElementById("tocDivBox");
    nowToc = false;
    tocbox.style.display = "none";

    button.innerText = " 📜 ";
    button.style.background = "";
    button.style.color = "red";
}

function handleGoToC() {
    let button = document.getElementById("floatingTocButton");
    var tocbox = document.getElementById("tocDivBox");

    if (!location.pathname) return;
    let absoURL = location.pathname;

    let ele = document.getElementById("inputParaNo");
    let rangeData = ele.getAttribute("para-range");
    let ranges = rangeData.split("-");
    let a = Number(ranges[0]);
    let b = Number(ranges[1]);

    let uEnter = ele.value;
    uEnter = Number(uEnter.trim());
    if (isNaN(uEnter)) {
        ele.value = "";
        alert("Enter a number in this range: " + rangeData);
        ele.focus();
        return;
    }

    if (uEnter >= a && uEnter <= b) {
        location.replace(absoURL + "#para" + uEnter);
        ele.value = "";
        onlyHideToc();
    } else {
        ele.value = "";
        alert("Enter a number in this range: " + rangeData);
        ele.focus();
        return;
    }
}

function enterKeyGoToc(e) {
    if (e.isComposing || e.keyCode == 229) {
        return;
    }
    if (e.key == "Enter" || e.keyCode == 13) {
        handleGoToC();
    }
}

function listenId(id, event, fn) {
    let ele = document.getElementById(id);
    if (!ele) return;
    ele.addEventListener(event, fn, {
        passive: false,
    });
}

window.onload = function () {
    listenId("floatingTocButton", "click", showHideToc);
    listenId("goParaButton", "click", handleGoToC);
    listenId("inputParaNo", "keyup", enterKeyGoToc);
    listenId("hideTocButton", "click", onlyHideToc);

    // Auto hide toc when click on a TOC a tag
    let aTagToc = document.getElementsByClassName("tocDivBox_a");
    if (!aTagToc) return;

    let iMax = aTagToc.length;
    if (iMax < 1) return;
    let i = 0;
    for (; i < iMax; i++) {
        aTagToc[i].addEventListener("click", onlyHideToc, {
            passive: false,
        });
    }
};
