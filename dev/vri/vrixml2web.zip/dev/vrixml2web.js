/**
 * VRI CSCD xml2web
 * To map file titles, more detail navigation in html
 * @uPnry 13-19 Mar 2021
 * https://github.com/vpnry/tipitaka/
 *
 * Why this?
 * Smartphone/iPad can not view the VRI CSCD
 */

/**--------------------------------------------
 * Do not run this file directly, but run the sh file
     bash vrixml2web.sh
 * --------------------------------------------
 */
 
/**--------------------------------------------
 * WARNING:
 * Roman digitalised pali text are copyright
 * by VRI, one may need to obtain their permission first
 * Created for a personal project
 * The code is messy and may have bugs,
 * Use at oneself risks, no warranty!
 * --------------------------------------------
 */

/**
 * Last updated 03 Apr 2021
 * Some files have issues with paragraph numbering, that is, for example,
 * "para1" is repeated more than 1 times.
 * In such files, the paragraph navigation function is disabled.
 */

const fs = require("fs");
const PATH = require("path");

let currentEncoding = "utf16le";
let inCSCD = "vri-cscd-xml";
const xmlTOC = "vri-toc-xml";
const PPA = "pta";

const T2700JS = "Title2700.js";
const T2700PHP = "Title2700.php";

const Range2700Name = "Range2700.js";
const Range217Name = "Range217.js";
const TocExpandHtmlName = "TocExpandHtml.js";
const TocExpandHtmlPlusName = "TocExpandHtmlPlus.js";
const BigBookSubFilesName = "BigBookSubFiles.js";

let pRANGE = "";
let totalFNoPara = 0;
let tempDir = "temp217";

runApp();

function runApp() {
    // Create output dir
    fs.mkdirSync(PPA, { recursive: true });

    // // Step 1, 2
    run1_TocXmlTo2700Titles(inCSCD, PPA, prepareBookPathTitle(xmlTOC));
    run2_makeTocDataForIndex(inCSCD, PPA, "true");

    // Step 3 requires step 1, 2 outputs
    run3_xmlToHTMLRunner(inCSCD, "cscd");

    // Step 4 requires step 1 outputs
    run4_combineTo217Books(tempDir);

    // Step 5 requires step 1 outputs
    run5_BigFiles_217UTF8_ToHTMLRunner(tempDir, "cscdbig");

    // Step 6 updates more, 217 whole book toc index
    run6_add217BookToToc();

    // Delete temp dir
    console.log("\nDone! Cleaning up temp dir");
    console.log("Deleting temp dir " + tempDir);

    rmDir(tempDir);
    console.log("\nDone all!");
}

function readFileExtractParaRange(f) {
    /**
     * @param string f: filepath
     * return string: number-number
     */

    let paraNo = "";
    let splitToken = "@@@@";
    let fName = getFileName(f);

    let fileNameNewPath = `${inCSCD}/${fName}`;
    let text = fs.readFileSync(fileNameNewPath, {
        encoding: currentEncoding,
        flag: "r",
    });

    // There are up to 3 cases to backup
    // <hi rend="paranum">131</hi>
    // <p rend="bodytext" n="653">
    // <p rend="hangnum" n="131">
    let currentMin = 0;
    let currentMax = 0;

    let mapT = new Map();

    text = text.replace(/<hi rend="paranum">(.*?)<\/hi>/g, (_, paranumber) => {
        paranumber = paranumber.trim();
        mapT.set(paranumber, paranumber);
    });

    text = text.replace(/<p rend="bodytext" n="(.*?)"/g, (_, paranumber) => {
        paranumber = paranumber.trim();
        mapT.set(paranumber, paranumber);
    });

    text = text.replace(/<p rend="hangnum" n="(.*?)"/g, (_, paranumber) => {
        paranumber = paranumber.trim();
        mapT.set(paranumber, paranumber);
    });

    if (mapT.size < 1) {
        totalFNoPara++;
        // console.log(
        //   `   ${totalFNoPara}. This sub-file has no para number: ${fName}`
        // );
        pRANGE += `"${fName}": "",\n`;

        return "";
    }

    for (let key of mapT.keys()) {
        paraNo += key.trim() + splitToken;
    }
    paraNo = paraNo.trim();
    paraNo = paraNo.slice(0, paraNo.lastIndexOf(splitToken)).trim();
    paraNo = paraNo.split(splitToken);

    let numbers = [];
    for (let t of paraNo) {
        let tt = t.trim();

        if (t.includes("-")) {
            t = t.split("-");
            if (t.length > 2) {
                console.log(
                    "fn readFileExtractParaRange: Para range has more than 2 points =>" +
                        tt +
                        " " +
                        f
                );
            }
            let s1 = t[0] + "";
            s1 = s1.trim();
            let s2 = t[t.length - 1] + "";
            s2 = s2.trim();
            let s2len = s2.length;

            let i = Number(s1);
            let ii = Number(s2);
            if (isNaN(i) || isNaN(ii)) {
                console.log(
                    "Error: Mal para range: not a number! =>" + tt + "->" + f
                );
                continue;
            }

            s1 = s1;
            if (ii < i) {
                s2 = s1.slice(0, -s2len) + s2 + "";
                s2 = s2.trim();
            }

            i = Number(s1);
            ii = Number(s2);
            if (isNaN(i) || isNaN(ii)) {
                console.log(
                    "Error: Forming a new stuff that are not a number! =>" +
                        i +
                        " " +
                        ii +
                        "->" +
                        f
                );
                continue;
            }

            numbers.push(Number(s1));
            numbers.push(Number(s2));
        } else {
            let singN = Number(tt);
            if (isNaN(singN)) {
                console.log(
                    "Error: Single point is not a number! =>" + tt + "->" + f
                );
                continue;
            }
            numbers.push(singN);
        }
    }

    // console.log(numbers + "");

    let a = Math.min(...numbers);
    let b = Math.max(...numbers);

    pRANGE += `"${fName}": "${a}-${b}",\n`;

    // add a space before [
    return ` ${a}-${b}`;
}

function expandRangesToMultiLinks(text, f) {
    // expand <a name="para7-8"></a> to <a name="para7"></a><a name="para8"></a>
    text = text.replace(/<a name="para(.*?)"><\/a>/g, (_, t) => {
        let tt = t;
        t = t.trim();
        let numbers = [];
        if (t.includes("-")) {
            t = t.split("-");
            if (t.length > 2) {
                console.log(
                    "fn expandRangesToMultiLinks: Para range has more than 2 points =>" +
                        tt +
                        " " +
                        f
                );
            }
            let s1 = t[0] + "";
            s1 = s1.trim();
            let s2 = t[t.length - 1] + "";
            s2 = s2.trim();
            let s2len = s2.length;

            let i = Number(s1);
            let ii = Number(s2);
            if (isNaN(i) || isNaN(ii)) {
                console.log("Error: Mal para range: not a number! =>" + tt);
            }

            s1 = s1;
            if (ii < i) {
                s2 = s1.slice(0, -s2len) + s2 + "";
                s2 = s2.trim();
            }

            // if s2 > s1 then no need to do anything, keep s2

            i = Number(s1);
            ii = Number(s2);
            if (isNaN(i) || isNaN(ii)) {
                console.log(
                    "Error: Forming a new stuff that are not a number! =>" +
                        i +
                        " " +
                        ii
                );
            }

            numbers.push(Number(s1));
            numbers.push(Number(s2));

            let a = Math.min(...numbers);
            let b = Math.max(...numbers);

            let res = "";

            for (; a <= b; a++) {
                res += `<a name="para${a}"></a>`;
            }

            return res;
        } else {
            return `<a name="para${t}"></a>`;
        }
    });

    return text;
}

function run6_add217BookToToc() {
    let resTr = "";

    const TocExpandHtml = require("./" + PPA + "/" + "TocExpandHtml");
    const Title217Html = require("./" + PPA + "/" + "Title217Html");
    const Range217 = require("./" + PPA + "/" + "Range217");

    for (let k of Object.keys(TocExpandHtml)) {
        let olink = TocExpandHtml[k];
        let k217 = k.replace("_toc_xml", ".html").replace("_", ".").trim();

        let cssListStyle = "";

        let title = Title217Html[k217];

        if (!title) {
            console.log("No book title, map error" + k + " > " + k217);
        }

        if (title.startsWith("Mūla")) {
            cssListStyle = ' class="bmul"';
        } else if (title.startsWith("Aṭṭhakathā")) {
            cssListStyle = ' class="batt"';
        } else if (title.startsWith("Tīkā")) {
            cssListStyle = ' class="btik"';
        } else if (title.startsWith("Añña")) {
            cssListStyle = ' class="bann"';
        } else {
            cssListStyle = "";
        }

        // only use the last part of the title
        title = title.slice(title.lastIndexOf(">") + 1).trim();

        let pararange = Range217[k217];
        if (pararange) {
            pararange = " " + pararange;
        } else {
            pararange = "";
        }

        // Add multi volume notes
        let fc = fs.readFileSync(`cscdbig/${k217}`, {
            encoding: currentEncoding,
            flag: "r",
        });

        if (
            fc.indexOf('<a name="M1.0001"></a>') > -1 &&
            fc.indexOf('<a name="M2.0001"></a>') > -1
        ) {
            console.log("Multi volume detected, will add a note for: " + k217);
            title = title + " (book 1 & 2)";
            console.log("TocExpandHtmlPlus add note (1 & 2)");
        }

        let ad = `<li${cssListStyle}><a href="cscdbig/${k217}" target="_blank">${title}</a>${pararange}</li><hr/>`;

        let nlink = olink.replace("<ul>", "<ul>" + ad);
        resTr += `"${k}": ` + "`" + nlink + "`,\n";
    }

    resTr = resTr.trim().slice(0, -1);
    resTr = resTr.trim();

    let TocExpandHtmlPlusNameData =
        "var TocExpandHtmlPlus = {\n" + resTr + "\n};\n\n";
    TocExpandHtmlPlusNameData += `if (module) { module.exports = TocExpandHtmlPlus; }`;

    fs.writeFileSync(
        PPA + "/" + TocExpandHtmlPlusName,
        TocExpandHtmlPlusNameData,
        {
            encoding: "utf8",
        }
    );

    console.log("Save! Added more menus: " + TocExpandHtmlPlusName);
}

// --------- step 1 ---------

function run1_TocXmlTo2700Titles(inCSCD, PPA, bookPathTitle) {
    console.log("\n---- Task: run1_TocXmlTo2700Titles");

    let resTr = "";
    let eWith = ".toc.xml";
    let allFiles = lsFileInDir(inCSCD);
    allFiles.sort();

    let selecedFiles = allFiles.filter(function (e) {
        e.toLowerCase();
        return e.endsWith(eWith);
    });

    let lenP = selecedFiles.length;
    console.log("Filtered files: " + lenP);

    let i = 0;
    for (let f of selecedFiles) {
        let fc = fs.readFileSync(f, { encoding: currentEncoding, flag: "r" });

        fc = fc.replace('<?xml version="1.0" encoding="UTF-16"?><tree>', "");

        let fName = getFileName(f);
        let title = parseTitlesInEachFile(fc, fName, bookPathTitle);

        title = title.trim();
        resTr += title + "\n";
        i++;
        // console.log(`${i}. title: ${f}`);
    }

    resTr = resTr.trim().slice(0, -1);
    resTr = resTr.trim();

    fs.writeFileSync(
        PPA + "/" + T2700PHP,
        "<?php \n$t2700 = array(\n" + resTr.replace(/:/g, "=>") + "\n);\n",
        { encoding: "utf8" }
    );

    let T2700JSData = "const TITLES = {\n" + resTr + "\n};\n\n";

    T2700JSData += `if (module) { module.exports = TITLES; }`;

    fs.writeFileSync(PPA + "/" + T2700JS, T2700JSData, {
        encoding: "utf8",
    });

    console.log(`Processed: ${i}/${lenP} files`);
    console.log(`Saved ` + PPA + "/" + T2700PHP);
    console.log(`Saved ` + PPA + "/" + T2700JS);

    let jsParseReturn = "{\n" + resTr + "\n}\n";
    return JSON.parse(jsParseReturn);
}

function prepareBookPathTitle(xmlTOC) {
    console.log("\n---- Task: prepareBookPathTitle");

    let GROUP = {
        "toc1.xml": "Mūla",
        "toc2.xml": "Aṭṭhakathā",
        "toc3.xml": "Tīkā",
        "toc4.xml": "Añña",
    };

    // let titlesObj = {}; // legacy, not used now
    let str = "";
    let pathArray = lsFileInDir(xmlTOC);
    pathArray.sort();
    let i = 0;

    let lenP = pathArray.length;
    console.log("Total files: " + lenP);

    for (let f of pathArray) {
        let fName = "/" + f;
        fName = fName.split("/");
        fName = fName[fName.length - 1].trim();

        if (fName == "tipitaka_toc.xml") continue;
        let fileGroup = GROUP[fName];
        let fc = fs.readFileSync(f, { encoding: "utf8", flag: "r" });
        fc = fc.trim();

        let fullPathParent = "";
        let lines = fc.split(/\r?\n/);
        for (let line of lines) {
            line = line.trim();
            if (line.length < 1 || line.indexOf("text=") < 0) {
                continue;
            } else if (line.indexOf("src=") < 0) {
                let parrent = line
                    .replace('<tree text="', "")
                    .replace('">', "")
                    .trim();
                fullPathParent = fileGroup + " > " + parrent;
                // titlesObj[fullPathParent] = [];
                continue;
            } else {
                let lineShort = line
                    .replace(`<tree text="`, "")
                    .replace(`" src="./cscd/`, "@@")
                    .replace(`" />`, "");
                // titlesObj[fullPathParent].push(lineShort);
                let lineArry = lineShort.split("@@");
                str +=
                    '"' +
                    lineArry[1].trim() +
                    '": "' +
                    fullPathParent +
                    " > " +
                    lineArry[0].trim() +
                    '",\n';
            }
        }
        i++;
    }
    // remove the last comma ,
    str = str.trim().slice(0, -1);
    let js = "{" + str + "}";

    let t217TocXml = "let Title217TocXml = {\n" + str + "\n};\n\n";
    t217TocXml += `if (module) { module.exports = Title217TocXml; }`;

    fs.writeFileSync(PPA + "/" + "Title217TocXml.js", t217TocXml);

    let titleForWholeBookStr = str.replace(/\.toc\.xml"/g, `.html"`);
    let Title217HtmlData =
        "let Title217Html = {\n" + titleForWholeBookStr + "\n};\n\n";
    Title217HtmlData += `if (module) { module.exports = Title217Html; }`;

    fs.writeFileSync(PPA + "/" + "Title217Html.js", Title217HtmlData);

    console.log(`Done! parsed 217 book titles: ${i}/${lenP} files`);
    console.log("Saved! " + PPA + "/" + "Title217TocXml.js");

    return JSON.parse(js);
}

function parseTitlesInEachFile(text, fName, bookPathTitle) {
    let result = "";
    let lines = text.trim().split(/\r?\n/);
    for (let line of lines) {
        line = line.trim();
        if (line.length < 1) {
            continue;
        }
        // <tree text="(2) paccayaniddeso" action="cscd/abh03m7.mul1.xml" target="text" />
        line = line.replace(
            /.*?text="(.*?)".*?action="(.*?)".*?$/g,
            (_, s1, s2) => {
                s1 = s1.trim();
                // Fix capital 12. kilesagocchakaṃ => 12. Kilesagocchakaṃ
                s1 = s1.replace(
                    /^(.*?)([a-zA-ZāīūṁṃṇḍḷṛṣśṭñṅĀĪŪṀṂṆḌḶṚṢŚṬÑṄ])/g,
                    (_, t1, t2) => {
                        return t1 + t2.toUpperCase();
                    }
                );
                let res = `"${s2.replace("cscd/", "")}" : "${bookPathTitle[
                    fName
                ].trim()} > ${s1.trim()}"`;
                return res;
            }
        );
        result += line + ",\n";
    }
    return result.trim();
}

// --------- step 2 ---------
function run2_makeTocDataForIndex(inDIr, PPA, parseParaRange = true) {
    /**
     * @param in out dir
     * return 2 js object files
     */

    console.log("\n---- Task: run2_makeTocDataForIndex");

    let resTr = "";
    let bigBookS = "";

    let selecedFiles = lsWithFilter(inDIr, ".toc.xml");
    let lenP = selecedFiles.length;
    console.log("Found .toc.xml files: " + lenP);

    let i = 0;
    for (let f of selecedFiles) {
        let text = fs.readFileSync(f, { encoding: currentEncoding, flag: "r" });
        text = text.replace(
            '<?xml version="1.0" encoding="UTF-16"?><tree>',
            ""
        );

        let tocInFile = parseTextToHtmlToc(text);
        let childFileAry = getSubFilesOfBigBook(text);

        // remove last ,
        childFileAry = childFileAry.trim().slice(0, -1);
        childFileAry = childFileAry.trim();

        let fName = getFileName(f);
        let nameM = fName.trim().replace(/\./g, "_");
        tocInFile = "`<ul>" + tocInFile.trim() + "</ul>`";

        childFileAry = "[" + childFileAry.trim() + "]";

        resTr += "'" + nameM.trim() + "': " + tocInFile + ",\n";
        bigBookS += "'" + nameM.trim() + "': " + childFileAry + ",\n";
        i++;
    }

    // slice to remove last ,
    resTr = resTr.replace(/\.xml"/g, `.html"`);

    resTr = resTr.trim().slice(0, -1);
    resTr = resTr.trim();

    bigBookS = bigBookS.trim().slice(0, -1);
    bigBookS = bigBookS.trim();

    let TocExpandHtmlData = "var TocExpandHtml = {\n" + resTr + "\n};\n\n";
    TocExpandHtmlData += `if (module) { module.exports = TocExpandHtml; }`;

    fs.writeFileSync(
        PPA + "/" + TocExpandHtmlName,
        TocExpandHtmlData,

        { encoding: "utf8" }
    );

    let BigBookSubFilesNameData =
        "var BigBookSubFiles = {\n" + bigBookS + "\n};\n\n";
    BigBookSubFilesNameData += `if (module) { module.exports = BigBookSubFiles; }`;

    fs.writeFileSync(PPA + "/" + BigBookSubFilesName, BigBookSubFilesNameData, {
        encoding: "utf8",
    });

    pRANGE = pRANGE.trim().slice(0, -1);
    pRANGE = pRANGE.trim();

    let Range2700NameData = "var Range2700 = {\n" + pRANGE + "\n};\n\n";
    Range2700NameData += `if (module) { module.exports = Range2700; }`;

    fs.writeFileSync(PPA + "/" + Range2700Name, Range2700NameData, {
        encoding: "utf8",
    });

    console.log(`Processed: ${i}/${lenP} files`);
    console.log(`Saved ` + PPA + "/" + TocExpandHtmlName);
    console.log(`Saved ` + PPA + "/" + BigBookSubFilesName);
    console.log(`Saved ` + PPA + "/" + Range2700Name);

    // let rangeStrParse = "{" + pRANGE + "}";
    // return JSON.parse(rangeStrParse);
}

function parseTextToHtmlToc(text, parseParaRange = true) {
    /**
     * @param text
     * return tocInFile li tag
     */

    let result = "";
    let lines = text.trim().split(/\r?\n/);
    for (let line of lines) {
        line = line.trim();
        if (line.length < 1) {
            continue;
        }
        // <tree text="(2) paccayaniddeso" action="cscd/abh03m7.mul1.xml" target="text" />
        line = line.replace(
            /.*?text="(.*?)".*?action="(.*?)".*?$/g,
            (_, fTile, fileLink) => {
                fTile = fTile.trim();

                // Fix capital 12. kilesagocchakaṃ => 12. Kilesagocchakaṃ
                fTile = fTile.replace(
                    /^(.*?)([a-zA-ZāīūṁṃṇḍḷṛṣśṭñṅĀĪŪṀṂṆḌḶṚṢŚṬÑṄ])/g,
                    (_, t1, t2) => {
                        return t1 + t2.toUpperCase();
                    }
                );

                let res = "";
                if (parseParaRange) {
                    res = `<li><a href="${fileLink}" target="_blank">${fTile.trim()}</a>${readFileExtractParaRange(
                        fileLink
                    )}</li>`;
                } else {
                    res = `<li><a href="${fileLink}" target="_blank">${fTile.trim()}</a></li>`;
                }
                return res;
            }
        );
        result += line;
    }
    return result.trim();
}

function getSubFilesOfBigBook(text, parseParaRange = true) {
    /**
     * @param text
     * return sub file paths
     */

    let result = "";
    let lines = text.trim().split(/\r?\n/);
    for (let line of lines) {
        line = line.trim();
        if (line.length < 1) {
            continue;
        }
        // <tree text="(2) paccayaniddeso" action="cscd/abh03m7.mul1.xml" target="text" />
        line = line.replace(
            /.*?text="(.*?)".*?action="cscd\/(.*?)".*?$/g,
            (_, fTile, fileLink) => {
                return `"${fileLink.trim()}"`;
            }
        );

        result += line + ",";
    }
    return result.trim();
}

// --------- step 3 ---------

function run3_xmlToHTMLRunner(inDir, outDir) {
    console.log("\n---- Task: run3_xmlToHTMLRunner");

    // These files are the outputs of step 1 & 2
    const TITLES = require("./" + PPA + "/" + T2700JS);
    const Range2700 = require("./" + PPA + "/" + Range2700Name);

    let ary = lsFileInDir(inDir);
    ary = ary.filter((e) => {
        return !e.endsWith(".toc.xml") && e.endsWith(".xml");
    });

    console.log("Filtered XML files: " + ary.length);
    console.log(
        "Pls wait for converting XML to HTML.\nIt may take a while ..."
    );

    let n = 0;
    for (let f of ary) {
        if (f.endsWith(".xml")) {
            n++;
            xslRunnerSaveHTML(f, inDir, outDir, TITLES, Range2700);
        }
    }
    console.log("Converted XML to HTML: " + n + " files");
}

function xslRunnerSaveHTML(f, inDir, outDir, TITLES, Range2700) {
    let bodyText = readFileExtractBody(f);

    bodyText = fixSpaceDotNoteBeforeBold(bodyText);

    let xml_TocMap = addAnchorBodyTextReturnMap(Range2700, bodyText, f);
    let thisTOC = xml_TocMap.get("toc");
    let text = xml_TocMap.get("xml").trim();
    text = convertXSLRulesToHtml(text, f);

    let fn = getFileName(f);
    let thisTile = TITLES[fn].trim();
    if (thisTile == undefined) {
        console.log("Error: No title for: " + f);
    } else {
        if (
            text.indexOf('<a name="M1.0001"></a>') > -1 &&
            text.indexOf('<a name="M2.0001"></a>') > -1
        ) {
            console.log(
                "TITLES: Multi volume detected, will add a note for: " + f
            );
            thisTile = thisTile + " (1 & 2)";
        }
    }

    let sHtml = `
<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="index, follow">

<title>${thisTile.trim()}</title>

<meta name="description" content="${thisTile.trim()}">
<meta property="og:title" content="${thisTile.trim()}">
<meta property="og:description" content="${thisTile.trim()}">
<meta property="twitter:title" content="${thisTile.trim()}">
<meta property="twitter:description" content="${thisTile.trim()}">

<link rel="apple-touch-icon" sizes="180x180" href="../pta/icons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../pta/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../pta/icons/favicon-16x16.png">
<link rel="manifest" href="../pta/icons/site.webmanifest">
<link rel="mask-icon" href="../pta/icons/safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="../pta/textAndMenu.css">
<script src="../pta/handleBookMenu.js"></script>

</head>

<body>

${thisTOC.trim()}

`;

    let eHtml = `\n\n</body>\n\n</html>\n`;

    text = sHtml.trim() + "\n\n" + text.trim() + eHtml;

    let dName = PATH.dirname(f);
    dName = dName.replace(inDir, outDir);
    fs.mkdirSync(dName, { recursive: true });

    let newPat = f.replace(inDir, outDir);
    let patExt = newPat.slice(0, newPat.lastIndexOf(".")).trim() + ".html";

    fs.writeFileSync(patExt, text, { encoding: "utf8" });
}

function readFileExtractBody(f) {
    let text = fs.readFileSync(f, { encoding: currentEncoding, flag: "r" });
    // The only case that vri put wrong para number
    if (f.endsWith("e0812n.nrf3.xml")) {
        text = text.replace(
            `<p rend="bodytext" n="179-"><hi rend="paranum">179-</hi> 184<hi rend="dot">.</hi>`,
            `<p rend="bodytext" n="179-184"><hi rend="paranum">179-184</hi><hi rend="dot">.</hi>`
        );
    }

    let a = text.indexOf("<body>") + "<body>".length;
    if (a <= "<body>".length) console.log("<body> tag error in file: " + f);
    let b = text.lastIndexOf("</body>");
    if (b < 0) console.log("</body> tag error in file: " + f);
    return text.slice(a, b).trim();
}

function fixSpaceDotNoteBeforeBold(text) {
    // -------- add space dot + bold -----------
    // <hi rend="dot">.</hi><hi rend="bold">Word => should be: <hi rend="dot">.</hi><hi rend="bold"> Word
    // 2 ways to fix
    // add space before word
    // return text.replace(/<hi rend="dot">\.<\/hi><hi rend="bold">([a-zA-ZāīūṁṃṇḍḷṛṣśṭñṅĀĪŪṀṂṆḌḶṚṢŚṬÑṄ])/g, `<hi rend="dot">.</hi><hi rend="bold"> $1`);

    // Add a space before the tag
    text = text.replace(
        /<hi rend="dot">\.<\/hi><hi rend="bold">([a-zA-ZāīūṁṃṇḍḷṛṣśṭñṅĀĪŪṀṂṆḌḶṚṢŚṬÑṄ])/g,
        `<hi rend="dot">.</hi> <hi rend="bold">$1`
    );

    // -------- add space note + bold -----------
    // </note><hi rend="bold">Word
    text = text.replace(
        /<\/note><hi rend="bold">([a-zA-ZāīūṁṃṇḍḷṛṣśṭñṅĀĪŪṀṂṆḌḶṚṢŚṬÑṄ])/g,
        `</note> <hi rend="bold">$1`
    );

    return text;
}

function addAnchorBodyTextReturnMap(Range2700, text, f = "") {
    let result = new Map();
    let contentLINEs = "";
    let onlyTOC = "";
    let typeMenu = [
        'rend="nikaya">',
        'rend="book">',
        'rend="chapter">',
        'rend="title">',
        'rend="subhead">',
        'rend="subsubhead">',
    ];

    let fName = getFileName(f);

    let anchorPrefix = fName.toLowerCase();
    anchorPrefix = anchorPrefix.trim() + "_";
    anchorPrefix = anchorPrefix.replace(/\./g, "_");
    anchorPrefix = anchorPrefix.replace(/_xml_/g, "_html_");

    let z = 0;
    let lines = text.split(/\r?\n/);

    for (let line of lines) {
        line = line.trim();
        if (line.length < 1) {
            contentLINEs += "\n";
            continue;
        }
        let prefixAnchor = "";
        for (let e of typeMenu) {
            if (line.indexOf(e) > -1) {
                let linkcode = anchorPrefix + z;
                prefixAnchor = `<a name="${linkcode}"></a>\n\n`;
                onlyTOC += turnTextTagToLink(line, linkcode) + "\n";
                z++;
                break;
            }
        }
        if (prefixAnchor) {
            contentLINEs += prefixAnchor + line + "\n";
        } else {
            contentLINEs += line + "\n";
        }
    }

    result.set("xml", contentLINEs);

    // Some files (like big combined 217 files), if the para1 is repeated >=2 times, we will disable paragraph navigation function)
    // If multi volumes are compined, will add a note to its title (1 & 2)
    let disMap = new Map();

    // Still in xml <pb ed="M" n="2.0001" />

    if (
        contentLINEs.indexOf('<pb ed="M" n="1.0001" />') > -1 &&
        contentLINEs.indexOf('<pb ed="M" n="2.0001" />') > -1
    ) {
        console.log(
            "addAnchorBodyTextReturnMap Multi volume detected, will print a note for: " +
                f
        );
        disMap.set("mulvol", "yes");
        if (contentLINEs.indexOf('<pb ed="M" n="0.0001" />') > -1) {
            console.log("======> 3 volumes detected " + f);
        }
    }

    let rexPara1 = /rend="paranum">1<\/hi>/g;
    let rexPara2 = /n="1"/g;
    let isRepeatPara1 = [...contentLINEs.matchAll(rexPara1)];
    let isRepeatPara2 = [...contentLINEs.matchAll(rexPara2)];

    if (isRepeatPara1.length >= 2 || isRepeatPara2.length >= 2) {
        console.log(
            "Repeated para1 detected, will disable paragraph navigation on: " +
                f
        );
        disMap.set("disnav", "yes");
    }

    result.set("toc", finaliseTocHtmlCode(onlyTOC, fName, Range2700, disMap));
    return result;
}

function finaliseTocHtmlCode(intoc, fName, Range2700, disMap) {
    intoc = intoc
        .replace(/<head rend=/g, "<p rend=")
        .replace(/<\/head>/g, "</p>");

    let toc = "<!-- start of head TOC -->\n";
    toc += '<p id="floatingTocButton"> 📜 </p>\n';
    toc += '<div id="tocDivBox" style="display: none;">\n';

    let multiVol = disMap.get("mulvol");
    let disNav = disMap.get("disnav");

    if (multiVol == "yes") {
        console.log("multiVol: yes");
        toc += "<p>This file contains both<br>Myanmar book 1 & 2.</p>\n";
    }

    if (Range2700[fName]) {
        if (disNav != "yes") {
            let r = Range2700[fName].trim();
            toc += '<label for="inputParaNo">Paragraph no. </label>\n';
            toc += `<input type="text" size="8" id="inputParaNo" para-range="${r}" placeholder="${r}"></input>\n`;
            toc += '<button id="goParaButton">Go</button>\n';
        } else if (disNav == "yes") {
            toc +=
                "<p>Paragraph navigation function<br>was disabled on this file.</p>\n";
            toc += '<button id="hideTocButton">Hide</button>\n';
        }
    } else {
        toc += '<button id="hideTocButton">Hide</button>\n';
    }

    toc += "<hr/>\n";
    toc += intoc.trim();
    toc += "\n</div>\n";
    toc += "<!-- end of head TOC -->\n";

    toc = toc.replace(/rend=/g, "class=");
    return toc;
}

function turnTextTagToLink(line, linkcode) {
    return line.replace(
        />(.*?)</g,
        `><a class="tocDivBox_a" href="#${linkcode}">$1</a><`
    );
}

function convertXSLRulesToHtml(text, f) {
    /**
     * Each xsl rule in the comments will be replaced with HTML
     */

    // <xsl:template match='hi[@rend="dot"]'>
    // <xsl:apply-templates/>
    // </xsl:template>

    // This rule transforms nothing, keeps the dot only
    /* THIS REPLACE MUST BE BEFORE THE OTHERS*/
    text = text.replace(/<hi rend="dot">.<\/hi>/g, `.`);

    // <xsl:template match='p[@rend="bodytext"]'>
    // <p class="bodytext">
    //   <!-- if the n attribute is set, create an HTML anchor for the paragraph in the form para### -->
    //   <xsl:if test="@n">
    //     <a>
    //       <xsl:attribute name="name">
    //         <xsl:text>para</xsl:text>
    //         <xsl:value-of select="@n"/>
    //       </xsl:attribute>
    //     </a>
    //   </xsl:if>
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // It means <p rend="bodytext" n="18"> => <p class="bodytext"><a name="para18"></a>

    text = text.replace(/<p rend="bodytext" n="(.*?)">/g, (_, s1) => {
        return `<p class="bodytext"><a name="para${s1.trim()}"></a>`;
    });
    // Back up if it does not have para number, simply replace rend= to class
    text = text.replace(/<p rend="bodytext"/g, `<p class="bodytext"`);

    // <xsl:template match='p[@rend="hangnum"]'>
    // <p class="hangnum">
    //   <!-- if the n attribute is set, create an HTML anchor for the paragraph in the form para### -->
    //   <xsl:if test="@n">
    //     <a>
    //       <xsl:attribute name="name">
    //         <xsl:text>para</xsl:text>
    //         <xsl:value-of select="@n"/>
    //       </xsl:attribute>
    //     </a>
    //   </xsl:if>
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    text = text.replace(/<p rend="hangnum" n="(.*?)">/g, (_, s1) => {
        return `<p class="hangnum"><a name="para${s1.trim()}"></a>`;
    });
    // Back up if it does not have para number, simply replace rend= to class
    text = text.replace(/<p rend="hangnum"/g, `<p class="hangnum"`);

    // <xsl:template match='p[@rend="unindented"]'>
    // <p class="unindented">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    text = text.replace(/<p rend="unindented"/g, `<p class="unindented"`);

    // <xsl:template match='p[@rend="indent"]'>
    // <p class="indent">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    text = text.replace(/<p rend="indent"/g, `<p class="indent"`);

    // <xsl:template match="note">
    // <span class="note">[<xsl:apply-templates/>]</span>
    // </xsl:template>

    // It means <note>viriyindriyaṃ (sī. syā.)</note> =>  <span class="note">[viriyindriyaṃ (sī. syā.)]</span>
    text = text.replace(/<note>/g, `<span class="note">[`);
    text = text.replace(/<\/note>/g, `]</span>`);

    // <xsl:template match='hi[@rend="bold"]'>
    // <span class="bld"><xsl:apply-templates/></span>
    // </xsl:template>

    // It means <hi rend="bold">Pabhedato</hi> to
    // <span class="bld">Pabhedato</span>

    text = text.replace(/<hi rend="bold"/g, `<span class="bld"`);
    text = text.replace(/<\/hi>/g, `</span>`);

    // <xsl:template match='hi[@rend="paranum"]'>
    // <span class="paranum"><xsl:apply-templates/></span>
    // </xsl:template>

    // <hi rend="paranum">584</hi> to <span class="paranum">584</span>

    text = text.replace(/<hi rend="paranum"/g, `<span class="paranum"`);
    text = text.replace(/<\/hi>/g, `</span>`);

    // <xsl:template match='p[@rend="centre"]'>
    // <p class="centered">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // <p rend="centre">Evaṃ ekavidhena rūpasaṅgaho.</p> to
    // <p class="centered">Evaṃ ekavidhena rūpasaṅgaho.</p>

    text = text.replace(/<p rend="centre"/g, `<p class="centered"`);

    // <xsl:template match='p[@rend="subsubhead"]'>
    // <p class="subsubhead">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // <p rend="subsubhead">Vīsatigāthāvaṇṇanā</p> to
    // <p class="subsubhead">Vīsatigāthāvaṇṇanā</p>

    text = text.replace(/<p rend="subsubhead"/g, `<p class="subsubhead"`);

    // <xsl:template match='p[@rend="book"]'>
    // <p class="book">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // <p rend="book">Dhammasaṅgaṇī-mūlaṭīkā</p> TO <p class="book">Dhammasaṅgaṇī-mūlaṭīkā</p>
    text = text.replace(/<p rend="book"/g, `<p class="book"`);

    // <xsl:template match='p[@rend="chapter"]'>
    // <p class="chapter">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // <p rend="chapter">1. Cittuppādakaṇḍo</p> <p class="chapter">1. Cittuppādakaṇḍo</p>
    text = text.replace(/<p rend="chapter"/g, `<p class="chapter"`);

    // <xsl:template match='p[@rend="subhead"]'>
    // <p class="subhead">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // <p rend="subhead">Aṭṭhakaṃ</p> <p class="subhead">Aṭṭhakaṃ</p>
    text = text.replace(/<p rend="subhead"/g, `<p class="subhead"`);

    // <xsl:template match='p[@rend="nikaya"]'>
    // <p class="nikaya">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // <p rend="nikaya">Abhidhammapiṭake</p> <p class="nikaya">Abhidhammapiṭake</p>
    text = text.replace(/<p rend="nikaya"/g, `<p class="nikaya"`);

    // <xsl:template match='p[@rend="title"]'>
    // <p class="title">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    // <p rend="title">Aṭṭhasālinī nāma</p> <p class="title">Aṭṭhasālinī nāma</p>
    text = text.replace(/<p rend="title"/g, `<p class="title"`);

    // <xsl:template match='p[@rend="gatha1"]'>
    // <p class="gatha1">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    text = text.replace(/<p rend="gatha1"/g, `<p class="gatha1"`);

    // <xsl:template match='p[@rend="gatha2"]'>
    // <p class="gatha2">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    text = text.replace(/<p rend="gatha2"/g, `<p class="gatha2"`);

    // <xsl:template match='p[@rend="gatha3"]'>
    // <p class="gatha3">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    text = text.replace(/<p rend="gatha3"/g, `<p class="gatha3"`);

    // <xsl:template match='p[@rend="gathalast"]'>
    // <p class="gathalast">
    // <xsl:apply-templates/>
    // </p>
    // </xsl:template>

    text = text.replace(/<p rend="gathalast"/g, `<p class="gathalast"`);

    // <xsl:template match="pb">
    // <a>
    // <xsl:attribute name="name">
    // <xsl:value-of select="@ed"/><xsl:value-of select="@n"/>
    // </xsl:attribute>
    // </a>
    // </xsl:template>

    // <p rend="bodytext">Tattha <pb ed="M" n="0.0008" /> khandhavibhaṅgo <pb ed="V" n="0.0009" /> suttan <pb ed="P" n="0.0008" /> .</p>
    // <p class="bodytext">Tattha <a name="M0.0008"></a> khandhavibhaṅgo <a name="V0.0009"></a> suttan <a name="P0.0008"></a> .</p>

    text = text.replace(/<pb ed="(.*?)" n="(.*?)" \/>/g, (_, s1, s2) => {
        // Convert number to string
        s1 = (s1 + "").trim();
        s2 = (s2 + "").trim();
        let t = "" + s1 + s2 + "";
        return `<a name="${t.trim()}"></a>`;
    });

    return expandRangesToMultiLinks(text, f);
}

// Step 4 combine

function run4_combineTo217Books(tempDir) {
    console.log("\n---- Task: run4_combineTo217Books");
    const LOG_FILENAME = "log_combine_217.txt";
    fs.mkdirSync(tempDir, { recursive: true });

    // These 2 are generated by run1_TocXmlTo2700Titles and run2_makeTocDataForIndex
    const BigBookSubFiles = require("./pta/BigBookSubFiles");
    const Title217Html = require("./pta/Title217Html");

    let i = 0;
    let b = 0;
    let w = 0;

    let log =
        "Book full title\nTotal chidren files for each book\nNo. bookFileName <= appended order";
    // Must ensure that the BigBookSubFiles source [keys] are in order
    // Double check with logfile

    for (let k of Object.keys(BigBookSubFiles)) {
        //abh02a_att_toc_xml to abh02a.att (add .html later)
        let book = k.replace(/_toc_xml/g, "").replace(/_/g, ".");
        book = book.trim();
        b++;
        log += "\n\n--- Book " + b + " ---\n";

        let bookTitle = Title217Html[book + ".html"];
        if (!bookTitle) console.log("Error: no book title for: " + book);
        log += bookTitle + "\n";

        let childAry = BigBookSubFiles[k];
        let totalSub = childAry.length;
        if (totalSub < 1) console.log("Error: no children files for: " + book);
        log += "\n    " + book + " has " + totalSub + " children files\n\n";

        let text = "";
        for (let f of childAry) {
            let t = readFileExtractBody(inCSCD + "/" + f.trim());
            text += t.trim() + "\n\n";
            i++;
            // Log append order
            log += (i < 10 ? "0" + i : i) + ". " + book + " <= " + f + "\n";
        }
        // add some text so that the body is not at the begining of file
        text =
            `<meta charset="utf-8" /><title>${bookTitle}</title>\n\n<body>\n\n` +
            text.trim() +
            "\n\n</body>\n\n</html>\n";

        fs.writeFileSync(tempDir + "/" + book.trim() + ".html", text.trim());
        w++;
    }

    console.log("Small files: " + i);
    console.log("Book: " + b);

    fs.writeFileSync(LOG_FILENAME, log);

    console.log("Writen joined files to ./" + tempDir + ": " + w);
    console.log("Double check app log: ./" + LOG_FILENAME + "\n");
}

// Step 5
function run5_BigFiles_217UTF8_ToHTMLRunner(inDir, outDir = "cscdbig") {
    console.log("\n---- Task: run5_BigFiles_217UTF8_ToHTMLRunner");

    currentEncoding = "utf8";
    pRANGE = "";
    inCSCD = inDir;

    let ary = lsFileInDir(inDir);
    ary = ary.filter((e) => {
        return e.endsWith(".html");
    });

    console.log("Filtered joined HTML files: " + ary.length);

    // prepare Range2700 on the go
    let z = 0;
    for (let f of ary) {
        z++;
        readFileExtractParaRange(f);
    }
    console.log(`Prepared para range on the go from: ${z} files`);

    pRANGE = pRANGE.trim().slice(0, -1);
    pRANGE = pRANGE.trim();

    let Range217NameData = "var Range217 = {\n" + pRANGE + "\n};\n\n";
    Range217NameData += `if (module) { module.exports = Range217; }`;

    fs.writeFileSync(PPA + "/" + Range217Name, Range217NameData, {
        encoding: "utf8",
    });

    const Range2700 = JSON.parse("{" + pRANGE + "}");
    const Title217Html = require("./pta/Title217Html");

    console.log(
        "Pls wait for converting XML rules to HTML.\nIt may take a while ..."
    );

    let n = 0;
    for (let f of ary) {
        n++;
        xslRunnerSaveHTML(f, inDir, outDir, Title217Html, Range2700);
    }
    console.log("Processed: " + n + " files\n");
}

// --------- small ultilities ---------

function getFileName(fpath) {
    let fName = "/" + fpath;
    fName = fName.split("/");
    return fName[fName.length - 1].trim();
}

function lsFileInDir(dir) {
    let files = [];
    function liD(dir) {
        fs.readdirSync(dir).forEach(function (f) {
            let fp = PATH.join(dir, f);
            if (fs.statSync(fp).isDirectory()) return liD(fp);
            files.push(fp);
        });
    }
    liD(dir);
    return files;
}

function lsWithFilter(inDIr, ex) {
    let filesOfDir = lsFileInDir(inDIr);
    filesOfDir.sort();
    let selecedFiles = filesOfDir.filter((e) => {
        e.toLowerCase();
        return e.endsWith(ex);
    });
    return selecedFiles;
}

function rmDir(dir) {
    try {
        fs.rmSync(dir, { recursive: true, force: true });
    } catch (e) {
        console.log("Error while trying to delete: " + dir);
        return "";
    }
    console.log("Deleted " + dir);
}
